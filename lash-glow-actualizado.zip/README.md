# Lash Glow AS – Actualización con sección "Trabajos"

## Qué se agregó

- Un nuevo apartado **Trabajos** entre *Servicios* y *Precios*, con las 3 fotos.
- El link **Trabajos** en el menú de navegación.
- Galería responsive: 3 columnas en compu, 2 en tablet y 1 en celular.
- Al tocar una foto se abre en grande (lightbox). Se cierra con la cruz, tocando afuera o con la tecla Esc.
- No se tocó nada del sistema de turnos, la agenda ni el envío por WhatsApp.

## Archivos

```
index.html          ← reemplaza el que está en GitHub
fotos/trabajo-1.jpg
fotos/trabajo-2.jpg
fotos/trabajo-3.jpg
```

La carpeta `fotos` tiene que quedar al lado del `index.html`, en la raíz del repositorio.

## Cómo subirlo a GitHub (desde la web)

1. Entrá al repositorio del sitio en GitHub.
2. Tocá **Add file → Upload files**.
3. Arrastrá el `index.html` nuevo y la carpeta `fotos` completa.
4. Esperá a que termine de subir y tocá **Commit changes**.
5. Si el sitio usa GitHub Pages, en unos minutos se actualiza solo.

> Importante: al arrastrar la carpeta `fotos`, GitHub la sube con las tres imágenes adentro.
> Si el repositorio ya tiene una carpeta `fotos`, se van a sumar los archivos nuevos.

## Si querés probarlo antes de subirlo

Abrí `index.html` con doble clic. Las fotos se ven porque están en la carpeta `fotos`.
